Perfect Parcel press kit
========================

A cosy Christmas packing puzzle for iPhone, by Paul Billings (Birmingham, UK).
Press page: https://www.paulbillings.co.uk/perfect-parcel
Contact: perfect-parcel@paulbillings.co.uk

screens/  six screenshots, 1206 x 2622 PNG, captured on iPhone 16 Pro
gifs/     three short GIFs: packing, sealing, the workshop
art/      logo, app icon (1024), Postmaster Robin (PNG 2000 px wide + SVG)

The trailer (30 s, 1080 x 1920) is a separate download on the press page.
You're welcome to use any of this to write about or feature the game.
